## Bài tập
1. Xây dựng lại mô hình `v0` với thay đổi như sau: trong mục `2.1`, thay vì dùng LabelEncoder của sklearn (thứ tự alphabet), dùng hàm map của dataframe để mã hóa kiểu loại sang kiểu số sao cho có tính thứ tự (ví dụ, Good: 3, Neutral: 2, Poor: 1).
    - Tham khảo:
    ```python
    data['Temperature_encoded'] = data['Temperature'].map( {'low':0, 'medium':1, 'high':2})
    ```
2. Áp dụng knn cho bài toán dự đoán dữ liệu giá nhà. Sử dụng class knn-regressor (https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsRegressor.html)

3. Thực hiện phân tích mô tả và áp dụng LogisticRegression cho bài toán dự đoán khách hàng tiềm năng.